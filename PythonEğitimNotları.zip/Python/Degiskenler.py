sayi = 10
print(sayi)
print()
strvar= "Yigit"
print(strvar)
print(strvar[1])
strvar = strvar + " Buraya Gel"
print(strvar)
print()
strvar = strvar * 2
print(strvar)
print(strvar[2:5])
print()

print(strvar.upper())
strvar = strvar.lower()
print(strvar)
print()
print(strvar.split())
print(strvar.split("a"))
print()
Yas1 = 18
print()
print(Yas1 == 18)
if(not Yas1 > 18):
    print("18 Yasindan buyuk degil")

liste = ['a', 'b', 'c', 'd']
print(liste)

liste = liste + ['f']
print(liste)

liste.append('g')
print(liste)

print(liste[3])

sayilar = [45,6897,45,12,84,1,1]
print(sayilar)

sayilar.sort()
print(sayilar)

sayilar.pop()
print(sayilar)

sayilar.reverse()
print(sayilar)

set(sayilar)
print(sayilar)

tup = ('a', 'b', 123)
print(tup)

counter = tup.count('a')
print(counter)

print(tup.index('b'))


dict1 = {
    'isim' : 'Yigit',
    'Sehir' : 'Balikesir',
    'Yas' : 21 
}
print(dict1['isim'])

ismi = dict1.get('Sehir')
print(ismi)

print(dict1.keys())
print(dict1.values())
print(dict1.items())


