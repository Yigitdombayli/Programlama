print("Yigit")
print("Dombayli")

print("Benim okulum {okul}".format(okul= "Esogu"))
print("Benim bolumum {bolum}".format(bolum = "Elektrik Elektronik"))