import csv
class urunler:
     
    all = []

    def __init__(self,katagori: str, fiyat: float, adet: int):
        assert fiyat >= 0, "Fiyat sifirdan buyuk olmalidir"
        assert adet >= 0, "Adet sifirdan buyuk olmalidir."

        
        self.katagori = katagori
        self.fiyat = fiyat
        self.adet = adet

        urunler.all.append(self)
    
    @classmethod
    def instantiate_from_csv(cls):
        with open('item.csv', 'r') as f:
            reader = csv.DictReader(f)
            items = list(reader)
        for item in items:
            urunler(
                katagori = item.get('katagori'),
                fiyat =int(item.get('fiyat')),
                adet = int(item.get('adet'))
            )       

    def urunsatis(self,alim_adet):
        self.adet = self.adet - alim_adet
        return f"{alim_adet} kadar ürün satilmiştir ve elimizde {self.adet} kadar urun kalmistir."
    def __repr__(self):
        return f"{self.__class__.__name__}({self.katagori}, {self.fiyat}, {self.adet})"

class teknolojik(urunler):
    def __init__(self, katagori: str, fiyat: float, adet: int, kirik_kontrol : int):
        super().__init__(katagori, fiyat, adet)

        self.kirik_kontrol = kirik_kontrol

urunler.instantiate_from_csv()
print(urunler.all)