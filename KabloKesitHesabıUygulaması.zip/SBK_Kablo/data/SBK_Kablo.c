#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<string.h>


typedef struct SBK_Kablo{

    char Kesit_Alani[10];
    float Toprakta;
    float Havada;
}kablo;



int main(){

kablo sbk_kablo[15];

strcpy(sbk_kablo[0].Kesit_Alani,"4x1.5");
sbk_kablo[0].Toprakta=27;
sbk_kablo[0].Havada=18.5;

strcpy(sbk_kablo[1].Kesit_Alani,"4x2.5");
sbk_kablo[1].Toprakta=36;
sbk_kablo[1].Havada=25;

strcpy(sbk_kablo[2].Kesit_Alani,"4x4");
sbk_kablo[2].Toprakta=47;
sbk_kablo[2].Havada=34;

strcpy(sbk_kablo[3].Kesit_Alani,"4x6");
sbk_kablo[3].Toprakta=59;
sbk_kablo[3].Havada=43;

strcpy(sbk_kablo[4].Kesit_Alani,"4x10");
sbk_kablo[4].Toprakta=79;
sbk_kablo[4].Havada=60;

strcpy(sbk_kablo[5].Kesit_Alani,"4x16");
sbk_kablo[5].Toprakta=102;
sbk_kablo[5].Havada=80;

strcpy(sbk_kablo[6].Kesit_Alani,"3x25+16");
sbk_kablo[6].Toprakta=133;
sbk_kablo[6].Havada=101;

strcpy(sbk_kablo[7].Kesit_Alani,"3x35+16");
sbk_kablo[7].Toprakta=159;
sbk_kablo[7].Havada=126;

strcpy(sbk_kablo[8].Kesit_Alani,"3x50+25");
sbk_kablo[8].Toprakta=188;
sbk_kablo[8].Havada=153;

strcpy(sbk_kablo[9].Kesit_Alani,"3x70+35");
sbk_kablo[9].Toprakta=232;
sbk_kablo[9].Havada=196;

strcpy(sbk_kablo[10].Kesit_Alani,"3x95+50");
sbk_kablo[10].Toprakta=280;
sbk_kablo[10].Havada=238;

strcpy(sbk_kablo[11].Kesit_Alani,"3x120+70");
sbk_kablo[11].Toprakta=318;
sbk_kablo[11].Havada=276;

strcpy(sbk_kablo[12].Kesit_Alani,"3x150+70");
sbk_kablo[12].Toprakta=359;
sbk_kablo[12].Havada=319;

strcpy(sbk_kablo[13].Kesit_Alani,"3x185+95");
sbk_kablo[13].Toprakta=406;
sbk_kablo[13].Havada=364;

strcpy(sbk_kablo[14].Kesit_Alani,"3x240+120");
sbk_kablo[14].Toprakta=473;
sbk_kablo[14].Havada=430;


int i;
int devam_durumu=1;

int izin_verilen_izdusum=0;
float Akim=0;
float guc=0;
float guc_faktoru=0;
float gerilim=0;
float Uzaklik=0;
float Gerilim_Dusumu=0;
float Iletken_Kaatsayisi=0;
float Iletken_Kesiti=0;
int iletkenlik_katsayi_durumu=-1;

int durum=-1;

while(devam_durumu == 1){
printf("****************************************\n");
printf("*                                      *\n");
printf("*                                      *\n");
printf("* SBK Kablo Kesit Hesaplama Uygulamasi *\n");
printf("*                                      *\n");
printf("*                                      *\n");
printf("****************************************\n\n\n");
printf("**Akim hesabi yapmak icin -- 1\n**Guc Hesabi Yapmak icin -- 2\n**Kablo Kesiti hesabi yapmak icin -- 3\n**Sadece Kesit Tablosunu Gormek icin -- 4'e basiniz\n");
scanf("%d",&durum);

switch(durum){

    case 1:
    printf("Lutfen gucu geiriniz (P) (Watt):\n");
    scanf("%f",&guc);
    printf("Lutfen Gerilimi Giriniz (U) (Volt):\n");
    scanf("%f",&gerilim);
    printf("Lutfen Guc Faktorunu Giriniz (cos fi):\n");
    scanf("%f",&guc_faktoru);

   Akim = (guc)/(sqrt(3)*gerilim*guc_faktoru);
   printf("Akim = %.2f Amper\n",Akim);
   
    printf("ONERILEN AKIM IZDUSUM KESITLERI\n");
    printf("-------------------------------\n");
    for(i=0; i<15; i++)
    {
        printf("Nominal Kesit:%s\tToprakta:%.2f Amper\tHavada:%.2f Amper\n\n",sbk_kablo[i].Kesit_Alani,sbk_kablo[i].Toprakta,sbk_kablo[i].Havada);
    }
    
      printf("\nDevam Etmek icin 1, Cikmak icin 0'a basin:\n");
    scanf("%d",&devam_durumu);
    
   break;

   case 2:
    printf("Lutfen Gerilimi Giriniz (U) (Volt):\n");
    scanf("%f",&gerilim);
    printf("Lutfen Akim Giriniz (I) (Amper):\n");
    scanf("%f",&Akim);
    printf("Lutfen Guc Faktorunu Giriniz (cos fi):\n");
    scanf("%f",&guc_faktoru);

    guc = sqrt(3)* gerilim* Akim* guc_faktoru;
    printf("Guc degeri = %f watt",guc);
    
      printf("\nDevam Etmek icin 1, Cikmak icin 0'a basin:\n");
    scanf("%d",&devam_durumu);
    
    
    break;
   case 3:
   
    printf("Lutfen izin verilen gerilim izdusumu yuzdesini Giriniz (e) (%%):\n");
    scanf("%d",&izin_verilen_izdusum);
    printf("Lutfen Gerilimi Giriniz (U) (Volt):\n");
    scanf("%f",&gerilim);
    printf("Lutfen gucu geiriniz (P) (Watt):\n");
    scanf("%f",&guc);
    printf("Lutfen uzakligi giriniz (L) (m):\n");
    scanf("%f",&Uzaklik);
   	do{
    printf("Lutfen iletkenlik katsayisini seciniz (k) (m/ohm*mm^2):\n1-Aluminyum\n2-Bakir\n");
    scanf("%d",&iletkenlik_katsayi_durumu);
    
	if(iletkenlik_katsayi_durumu == 1)
    {
    	Iletken_Kaatsayisi = 36;
    	
	}
	else if(iletkenlik_katsayi_durumu == 2)
	{
		Iletken_Kaatsayisi = 56;
	}
    
}while(iletkenlik_katsayi_durumu !=1 && iletkenlik_katsayi_durumu !=2);
    Iletken_Kesiti = (100*guc*Uzaklik)/(Iletken_Kaatsayisi*izin_verilen_izdusum*gerilim*gerilim);

    printf("\nGerekli olan iletken kesiti = %.2f mm^2\n\n", Iletken_Kesiti);
    printf("ONERILEN AKIM IZDUSUM KESITLERI\n");
    printf("-------------------------------\n");
    for(i=0; i<15; i++)
    {
        printf("Nominal Kesit:%s\tToprakta:%.2f Amper\tHavada:%.2f Amper\n\n",sbk_kablo[i].Kesit_Alani,sbk_kablo[i].Toprakta,sbk_kablo[i].Havada);
    }

    printf("\nDevam Etmek icin 1, Cikmak icin 0'a basin:\n");
    scanf("%d",&devam_durumu);

    break;
    
    case 4:
    	printf("ONERILEN AKIM IZDUSUM KESITLERI\n");
    printf("-------------------------------\n");
    for(i=0; i<15; i++)
    {
        printf("Nominal Kesit:%s\tToprakta:%.2f Amper\tHavada:%.2f Amper\n\n",sbk_kablo[i].Kesit_Alani,sbk_kablo[i].Toprakta,sbk_kablo[i].Havada);
    }

    printf("\nDevam Etmek icin 1, Cikmak icin 0'a basin:\n");
    scanf("%d",&devam_durumu);
    
    break;
}
}
system("pause");


return 0;
}
